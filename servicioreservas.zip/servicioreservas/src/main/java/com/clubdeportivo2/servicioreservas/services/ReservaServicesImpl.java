package com.clubdeportivo2.servicioreservas.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.clubdeportivo2.servicioreservas.client.CanchaClient;
import com.clubdeportivo2.servicioreservas.model.Reserva;
import com.clubdeportivo2.servicioreservas.repository.ReservaRepository;

import feign.FeignException;

import java.util.List;

@Service
public class ReservaServicesImpl implements ReservaServices {

    @Autowired
    private ReservaRepository reservaRepository;

    @Autowired
    private CanchaClient canchaClient;    


    @Override
    public Reserva crearReserva(Reserva reserva) {
        try {
            // 1. Validamos con el otro microservicio
            canchaClient.obtenerCancha(reserva.getCanchaId());
            
            // 2. Si llegamos aquí y no lanzó error, la cancha existe. Guardamos.
            return reservaRepository.save(reserva);
            
        } catch (FeignException.NotFound e) {
            // 3. Si el otro servicio responde 404, lanzamos nuestra lógica
            throw new RuntimeException("Error: La cancha con ID " + reserva.getCanchaId() + " no existe.");
        } catch (FeignException e) {
            // 4. Otros errores (ej: servicio de canchas caído)
            throw new RuntimeException("El servicio de canchas no está disponible actualmente.");
        }
    }



    @Override
    public List<Reserva> listarReservas() {
        return reservaRepository.findAll();
    }

   

    @Override
    public List<Reserva> buscarReservasPorCancha(Long canchaId) {
        return reservaRepository.findByCanchaId(canchaId);
    }

    

}
